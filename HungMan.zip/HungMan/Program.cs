﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HungMan
{
    class Program
    {
        static void Main(string[] args)
        {
            bool a = true;
            Console.WriteLine("Welcome to Hungman");
            string[] listwords = new string[10];
            listwords[0] = "basket";
            listwords[1] = "animal";
            listwords[2] = "wallet";
            listwords[3] = "laptop";
            listwords[4] = "orange";
            listwords[5] = "summer";
            listwords[6] = "history";
            listwords[7] = "icecream";
            listwords[8] = "program";
            listwords[9] = "weed";

            Random randGen = new Random();
            var idx = randGen.Next(0, 10);
            string mysteryWord = listwords[idx];
            char[] guess = new char[mysteryWord.Length];
            Console.WriteLine("Please enter you guess:");

            for (int i = 0; i < mysteryWord.Length; i++)
            guess[i] = '*';

            while (a)
            {
                char playerGuess = char.Parse(Console.ReadLine());
                for (int j = 0; j < mysteryWord.Length; j++)
                {
                    if (playerGuess == mysteryWord[j])
                        guess[j] = playerGuess;
                }
                Console.WriteLine(guess);
                if (new string(guess) == mysteryWord)
                    a = false;
            }
            Console.WriteLine("You got the word :)");
            Console.ReadKey();


        }
    }
}
